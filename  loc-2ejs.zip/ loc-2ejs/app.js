const express=require("express");
const app=express();

app.set("view engine","ejs");

let anuj={
    name:"anuj sonkar",
    roll:30
}


app.get(("./"),(req,res)=>{

    res.render("user",{anuj});


})


app.listen(3000,()=>{

    console.log("server is running at 3000");
    

})