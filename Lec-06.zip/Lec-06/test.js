const express=require("express");

const mongoose=require("mongoose");

const app=express();

app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.set("view engine","ejs");

mongoose.connect("mongodb://127.0.0.1:27017/hostel")
// mongoose.connect("mongodb+srv://anujsonkar12bicbly:Anuj123@cluster0.lfh13xl.mongodb.net/?appName=Cluster0")
.then(() =>{
    console.log("DB Connected")
})
.catch(() =>{
    console.log("error hai")
})

const studentSchema=new mongoose.Schema({
  name:String,
  age:Number,
  course:String,

  ip: {            // ager hum ye chhate hai ki humare ip ke ek request jaye to hume ip ko unique krna hoga...
    type:String,
    minlength:4,
    unique:true,

  },

});



// model (collection create hota hai mongodb ke ander )

const student=mongoose.model("student",studentSchema);

app.get("/getdata",(req,res)=>{
    res.render("home.ejs")
})



// app.get("/test",async(req,res)=>{

//     //find()
//     //findone()

//     let data= await student.findOne({name:"Anuj sonkar"})
//     console.log(data);
//     res.send("bye..testing route..")
    
// })



app.get("/test",async(req,res)=>{

    //find()
    //findone()

    //update karna 


    // let data = await student.updateMany({name:"Anuj sonkar"},{name:"naman"});  // phele name pe kiska change krna hai or dusre bracket me us pe kya change karna hai...
 //    let data = await student.updateOne({name:"Anuj sonkar"},{name:"naman"});    // updateMany se database me jitni jagan name hoga sab jagan change kar dega..
                                                                                //updateOne sirf ek bar change karta hai database me..
    


 //    let data = await student.deleteMany({name:"Anuj sonkar"},{name:"naman"});  // deleteMany se jitna sara delete ho jata hai baki ka code sir ke github se lena hai..  isse hume ye pta nhi chla hai ki kiska data delete hua hai 


        // let data = await student.deleteMany(    // $gte :- ka use candition ke liye use karte hai ki jiski age 60 se km hoga woh sab delete ho jayega 
        //     {age:{$gte: 80}}

        // );


        let data= await
        
       console.log(data);  
       
       
       res.send("bye..testing route..")
    
})







app.get("/",async(req,res)=>{  // router

    //async task awit..

    let allstudent= await student.find();
    // console.log(allstaff);

    let obj={
        "name":"anuj",
        age:18
    }
    
    
    // res.send("home page");

    res.render("students.ejs",{allstudent})
})





app.get("/insertdata",(req,res)=>{
    res.render("form.ejs");
})





app.post("/createdata",async(req,res)=>{

    let obj={
        name:"naman",
        age:20,
        "course":"webD"
    }
    console.log(req.body);
    

    let data=await student.create(req.body)
    console.log(data);
    
    res.send("data saved..")
})


app.listen(3000,()=>{
    console.log("server is running at 3000");
    
})