const express=require("express");

const mongoose=require("mongoose");

const app=express();


app.set("view engine","ejs");
mongoose.connect("mongodb://127.0.0.1:27017/hostel")
.then(() =>{
    console.log("DB Connected")
})
.catch(() =>{
    console.log("error hai")
})

const StaffSchema=new mongoose.Schema({
  name:String,
  role:String,
  age:Number,
});

// model 

const Staff=mongoose.model("Staff",StaffSchema);






app.get("/",async(req,res)=>{

    //async task awit..

    let allstaff= await Staff.find();
    console.log(allstaff);

    let obj={
        "name":"anuj",
        age:18
    }
    
    
    // res.send("home page");
    res.render("staff.ejs",{allstaff})
})


app.listen(3000,()=>{
    console.log("server is running at 3000");
    
})