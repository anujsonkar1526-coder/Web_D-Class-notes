const express=require("express");

const mongoose=require("mongoose");

const app=express();

app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.set("view engine","ejs");

// mongoose.connect("mongodb://127.0.0.1:27017/hostel")
mongoose.connect("mongodb+srv://anujsonkar12bicbly:Anuj123@cluster0.lfh13xl.mongodb.net/?appName=Cluster0")
.then(() =>{
    console.log("DB Connected")
})
.catch(() =>{
    console.log("error hai")
})

const studentSchema=new mongoose.Schema({
  name:String,
  age:Number,
  course:String,
});

// model (collection create hota hai mongodb ke ander )

const student=mongoose.model("student",studentSchema);






app.get("/",async(req,res)=>{  // router

    //async task awit..

    let allstudent= await student.find();
    // console.log(allstaff);

    let obj={
        "name":"anuj",
        age:18
    }
    
    
    // res.send("home page");

    res.render("students.ejs",{allstudent})
})

app.get("/insertdata",(req,res)=>{
    res.render("form.ejs");
})



app.post("/createdata",async(req,res)=>{

    let obj={
        name:"naman",
        age:20,
        "course":"webD"
    }
    console.log(req.body);
    

    let data=await student.create(req.body)
    console.log(data);
    
    res.send("data saved..")
})


app.listen(3000,()=>{
    console.log("server is running at 3000");
    
})